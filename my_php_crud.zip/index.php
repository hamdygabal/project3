<?php
// index.php - list users
include 'config.php'; // rename config.sample.php to config.php

$res = $conn->query('SELECT * FROM users ORDER BY id DESC');
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Users - Simple CRUD</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Users</h1>
  <p><a class="button" href="create.php">Add New User</a></p>
  <table>
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Created</th><th>Actions</th></tr></thead>
    <tbody>
    <?php while($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?php echo htmlspecialchars($row['id']); ?></td>
        <td><?php echo htmlspecialchars($row['name']); ?></td>
        <td><?php echo htmlspecialchars($row['email']); ?></td>
        <td><?php echo htmlspecialchars($row['created_at']); ?></td>
        <td class="actions">
          <a class="button" href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
          <a class="button danger" href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
