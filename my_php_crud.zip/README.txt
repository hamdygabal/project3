Project: Simple PHP MySQL CRUD
------------------------------
Files included:
- index.php       : list users + links to add/edit/delete
- create.php      : form to add a user
- edit.php        : form to edit a user
- delete.php      : deletes a user (via GET id)
- config.sample.php : sample DB config (rename to config.php and edit)
- init.sql        : SQL to create database & table
- style.css       : simple styles

How to use:
1. Upload the ZIP contents to your domain's httpdocs (Plesk) or the document root.
2. Rename config.sample.php to config.php and edit DB credentials:
   - $db_host, $db_user, $db_pass, $db_name
3. Create the database and table:
   - Use Plesk Databases → Import SQL (init.sql) OR run mysql -u root -p < init.sql
4. Make sure files owned by the web user (on Plesk: chown -R <username>:psacln /var/www/vhosts/yourdomain.com/httpdocs)
5. Visit https://yourdomain or http://yourdomain to use the app.

Security notes:
- This is a simple demo. For production, add CSRF protection, input validation, password hashing, and proper error handling.
