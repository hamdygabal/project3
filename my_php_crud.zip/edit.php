<?php
include 'config.php';
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) die('Invalid ID');
$stmt = $conn->prepare('SELECT * FROM users WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
if (!$user) die('User not found');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($name === '' || $email === '') {
        $error = 'Name and email are required.';
    } else {
        $up = $conn->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
        $up->bind_param('ssi', $name, $email, $id);
        if ($up->execute()) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Update failed: ' . $conn->error;
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit User</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Edit User</h1>
  <?php if ($error): ?><p style="color:red;"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
  <form method="post">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
    <label>Email</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
    <button class="button success" type="submit">Update</button>
    <a class="button" href="index.php">Back</a>
  </form>
</div>
</body>
</html>
