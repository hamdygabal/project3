<?php
include 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if ($name === '' || $email === '') {
        $error = 'Name and email are required.';
    } else {
        $stmt = $conn->prepare('INSERT INTO users (name, email) VALUES (?, ?)');
        $stmt->bind_param('ss', $name, $email);
        if ($stmt->execute()) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Insert failed: ' . $conn->error;
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Add User</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <h1>Add User</h1>
  <?php if ($error): ?><p style="color:red;"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
  <form method="post">
    <label>Name</label>
    <input type="text" name="name" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <button class="button success" type="submit">Save</button>
    <a class="button" href="index.php">Back</a>
  </form>
</div>
</body>
</html>
