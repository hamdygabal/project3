<?php
// Rename this file to config.php and put real credentials
$db_host = 'localhost';
$db_user = 'db_user';
$db_pass = 'db_password';
$db_name = 'my_crud_db';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>